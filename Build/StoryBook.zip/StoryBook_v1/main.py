from kivymd.app import MDApp
from kivy.uix.screenmanager import ScreenManager

from screens.splash import SplashScreen
from screens.home import HomeScreen
from screens.love import LoveScreen
from screens.horror import HorrorScreen
from screens.funny import FunnyScreen
from screens.favorite import FavoriteScreen
from screens.admin import AdminScreen


class StoryBookApp(MDApp):

    ADMIN_PASSWORD = "2316"

    def build(self):
        self.title = "StoryBook"

        sm = ScreenManager()

        self.favorite_screen = FavoriteScreen(name="favorite")

        sm.add_widget(SplashScreen(name="splash"))
        sm.add_widget(HomeScreen(name="home"))
        sm.add_widget(LoveScreen(name="love"))
        sm.add_widget(HorrorScreen(name="horror"))
        sm.add_widget(FunnyScreen(name="funny"))
        sm.add_widget(self.favorite_screen)
        sm.add_widget(AdminScreen(name="admin"))

        return sm


if __name__ == "__main__":
    StoryBookApp().run()