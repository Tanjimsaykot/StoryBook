from kivymd.uix.screen import MDScreen
from kivymd.uix.label import MDLabel
from kivy.clock import Clock


class SplashScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.add_widget(MDLabel(text="📚 StoryBook", halign="center"))

    def on_enter(self):
        Clock.schedule_once(self.go_home, 2)

    def go_home(self, dt):
        self.manager.current = "home"