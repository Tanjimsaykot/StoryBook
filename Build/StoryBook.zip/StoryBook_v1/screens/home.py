from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton


class HomeScreen(MDScreen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        layout = MDBoxLayout(orientation="vertical", spacing="15dp", padding="20dp")

        layout.add_widget(MDRaisedButton(text="❤️ Love", on_release=lambda x: self.go("love")))
        layout.add_widget(MDRaisedButton(text="👻 Horror", on_release=lambda x: self.go("horror")))
        layout.add_widget(MDRaisedButton(text="😂 Funny", on_release=lambda x: self.go("funny")))
        layout.add_widget(MDRaisedButton(text="⭐ Favorite", on_release=lambda x: self.go("favorite")))
        layout.add_widget(MDRaisedButton(text="🛠 Admin", on_release=lambda x: self.go("admin")))

        self.add_widget(layout)

    def go(self, screen):
        self.manager.current = screen