from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton


class FavoriteScreen(MDScreen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.favorites = []
        self.build()

    def build(self):
        self.clear_widgets()

        layout = MDBoxLayout(
            orientation="vertical",
            spacing="15dp",
            padding="20dp"
        )

        title = MDLabel(
            text="⭐ Favorite Stories",
            halign="center"
        )

        self.label = MDLabel(
            text="No Favorites Yet",
            halign="center"
        )

        back_btn = MDRaisedButton(
            text="⬅ Back",
            on_release=self.go_back
        )

        layout.add_widget(title)
        layout.add_widget(self.label)
        layout.add_widget(back_btn)

        self.add_widget(layout)

    def add_favorite(self, text):
        self.favorites.append(text)
        self.label.text = "\n\n".join(self.favorites)

    def go_back(self, *args):
        self.manager.current = "home"