from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.label import MDLabel
from kivymd.app import MDApp
import storage


class HorrorScreen(MDScreen):

    def on_enter(self):
        self.build()

    def build(self):
        self.clear_widgets()

        layout = MDBoxLayout(orientation="vertical", spacing="15dp", padding="20dp")

        layout.add_widget(MDLabel(text="👻 Horror Stories", halign="center"))

        for story in storage.read("horror"):
            layout.add_widget(MDRaisedButton(
                text=story,
                on_release=lambda x, s=story: self.open(s)
            ))

        layout.add_widget(MDRaisedButton(text="⬅ Back", on_release=lambda x: self.back()))

        self.add_widget(layout)

    def open(self, text):
        MDApp.get_running_app().favorite_screen.add_favorite(text)

        self.clear_widgets()

        layout = MDBoxLayout(orientation="vertical", spacing="15dp", padding="20dp")

        layout.add_widget(MDLabel(text=text, halign="center"))

        layout.add_widget(MDRaisedButton(text="⬅ Back", on_release=lambda x: self.build()))

        self.add_widget(layout)

    def back(self):
        self.manager.current = "home"