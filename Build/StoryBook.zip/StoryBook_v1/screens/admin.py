from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.textfield import MDTextField
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.label import MDLabel
from kivymd.app import MDApp
import storage


class AdminScreen(MDScreen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.selected_cat = None
        self.selected_story = None

        self.build_login()

    # ---------------- LOGIN ----------------
    def build_login(self):
        self.clear_widgets()

        layout = MDBoxLayout(orientation="vertical", spacing="15dp", padding="20dp")

        self.pass_input = MDTextField(hint_text="Password", password=True)

        layout.add_widget(MDLabel(text="🔐 Admin Login", halign="center"))
        layout.add_widget(self.pass_input)

        layout.add_widget(MDRaisedButton(text="Login", on_release=self.check))
        layout.add_widget(MDRaisedButton(text="Back", on_release=lambda x: self.go()))

        self.add_widget(layout)

    # ---------------- CHECK ----------------
    def check(self, *args):
        app = MDApp.get_running_app()

        if self.pass_input.text == app.ADMIN_PASSWORD:
            self.build_panel()
        else:
            self.pass_input.text = ""

    # ---------------- PANEL ----------------
    def build_panel(self):
        self.clear_widgets()

        self.app = MDApp.get_running_app()

        layout = MDBoxLayout(orientation="vertical", spacing="10dp", padding="20dp")

        # ===== ADD INPUT SECTION =====
        self.story_input = MDTextField(hint_text="Enter Story")
        self.cat_input = MDTextField(hint_text="love / horror / funny")

        layout.add_widget(self.story_input)
        layout.add_widget(self.cat_input)

        layout.add_widget(MDRaisedButton(text="➕ Add Story", on_release=self.add_story))

        # ===== CATEGORY BUTTONS =====
        layout.add_widget(MDRaisedButton(text="Love", on_release=lambda x: self.load("love")))
        layout.add_widget(MDRaisedButton(text="Horror", on_release=lambda x: self.load("horror")))
        layout.add_widget(MDRaisedButton(text="Funny", on_release=lambda x: self.load("funny")))

        # ===== STORY LIST =====
        self.box = MDBoxLayout(orientation="vertical", spacing="5dp")

        layout.add_widget(self.box)

        layout.add_widget(MDRaisedButton(text="🗑 Delete Selected", on_release=self.delete))
        layout.add_widget(MDRaisedButton(text="Logout", on_release=lambda x: self.build_login()))

        self.add_widget(layout)

    # ---------------- ADD STORY (FIXED) ----------------
    def add_story(self, *args):
        text = self.story_input.text.strip()
        cat = self.cat_input.text.strip().lower()

        if text and cat in ["love", "horror", "funny"]:
            storage.add(cat, text)

            self.story_input.text = ""
            self.cat_input.text = ""

            if self.selected_cat == cat:
                self.load(cat)

    # ---------------- LOAD ----------------
    def load(self, cat):
        self.selected_cat = cat
        self.box.clear_widgets()

        for story in storage.read(cat):
            self.box.add_widget(
                MDRaisedButton(
                    text=story,
                    on_release=lambda x, s=story: self.select(s)
                )
            )

    # ---------------- SELECT ----------------
    def select(self, story):
        self.selected_story = story

    # ---------------- DELETE ----------------
    def delete(self, *args):
        if self.selected_cat and self.selected_story:
            storage.delete(self.selected_cat, self.selected_story)
            self.load(self.selected_cat)

    # ---------------- BACK ----------------
    def go(self, *args):
        self.manager.current = "home"