import os

DATA_DIR = "data"


def ensure():
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
    except:
        pass


def path(cat):
    return os.path.join(DATA_DIR, f"{cat}.txt")


def read(cat):
    ensure()
    file_path = path(cat)

    try:
        if not os.path.exists(file_path):
            return []

        with open(file_path, "r", encoding="utf-8") as f:
            return [i.strip() for i in f.readlines()]
    except:
        return []


def write(cat, data):
    ensure()
    file_path = path(cat)

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            for i in data:
                f.write(i + "\n")
    except:
        pass


def add(cat, text):
    data = read(cat)
    data.append(text)
    write(cat, data)


def delete(cat, text):
    data = read(cat)

    if text in data:
        data.remove(text)

    write(cat, data)